package test.billy.jee.tc;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

public class Servlet0 extends HttpServlet {
    private static final long serialVersionUID = 1L;

	@Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
	    service0(req, resp);
    }

	private void service0(HttpServletRequest req, HttpServletResponse resp) {
	    String id = req.getParameter("id");
	    System.out.println("id=" + id);
        
         showRequestInfo(req);
    }
    
       /**
     * show request information, as below:
     *  <ul>
     *      <li>class name of <code>HttpServletRequest</code></li>
     *      <li>url with queryString</li>
     *      <li>parameters</li>
     *  </ul>
     * @param request
     */
    private void showRequestInfo(HttpServletRequest request) {
        System.out.println("request class: " + request.getClass().getName());
        StringBuffer requestURL = request.getRequestURL();
        String queryString = StringUtils.trimToEmpty(request.getQueryString());
        if (StringUtils.isNotBlank(queryString)) {
            requestURL.append("?").append(queryString);
        }
        System.out.println("url: " + requestURL);
        
        System.out.println("parameters: ");
        Enumeration<?> parameterNames = request.getParameterNames();            
        while (parameterNames.hasMoreElements()) {
            Object nextElement = parameterNames.nextElement();
            String key = String.valueOf(nextElement);
//                String value = request.getParameter(key);
            String[] values = request.getParameterValues(key);
            String valuePre = " ";
            String valuePost = StringUtils.EMPTY;
            if (values.length > 1) {
                valuePre += "[arr] | ";
                valuePost = Arrays.asList(values).toString();
            } else {
                valuePre += "[   ] | ";
                valuePost = values[0];
            }
            System.out.println(valuePre + key + "=" + valuePost); 
        }
    }
        
    

}
